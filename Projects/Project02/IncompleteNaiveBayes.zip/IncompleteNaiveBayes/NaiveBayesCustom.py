#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
from collections import defaultdict
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import CountVectorizer, TfidfTransformer
from ProbDist import *
from collections import defaultdict



yelp = pd.read_json('./yelp_dataset/yelp_academic_dataset_review.json', lines=True, nrows=1000)
# yelp = pd.read_json('./yelp_dataset/yelp_academic_dataset_review.json', lines=True)
yelp['text'] = yelp['text'].astype('str')

train, test = train_test_split(yelp, train_size=0.8) 


# In[2]:


train, test = train_test_split(yelp, train_size=0.8) 

input_columns = ['text']
irrelevant_columns = ['review_id', 'user_id', 'business_id', 'date']
output_columns = ['stars', 'useful', 'funny', 'cool']

x = train["text"].sort_index()

p_ratings = defaultdict(int)
p_has_word_in_ratings = defaultdict(int)

# Vectorize the training and testing data
v = CountVectorizer(ngram_range=(1, 1))
x = v.fit_transform(x)

for rating_type in output_columns:
    # replace all null with -1
    train[rating_type].fillna(-1, inplace=True)
    p_has_word_in_rating = JointProbDist(["word", "star_rating"])
    p_rating = defaultdict(int)
    
    for _, row in train.iterrows():
        words = row["text"].split()
        for word in words:
            p_has_word_in_rating[word, row[rating_type]] += 1
            p_rating[row[rating_type]] += 1
    
    p_has_word_in_rating.normalize()

    # probabilities for each star rating out of total
    total_prob = sum(p_rating.values())
    for key in p_rating.keys():
        p_rating[key] /= total_prob
    
    p_ratings[rating_type] = p_rating
    p_has_word_in_ratings[rating_type] = p_has_word_in_rating


# In[7]:


correct_predictions = {1: 0, 2: 0, 3: 0, 4: 0, 5: 0}
incorrect_predictions = {1: 0, 2: 0, 3: 0, 4: 0, 5: 0}
total_predictions = {1: 0, 2: 0, 3: 0, 4: 0, 5: 0}

for rating_type in output_columns:
    temp_rating_prob = {}
    for index, message in test.iterrows():
        
        for star_rating in range(1, 6):
            temp_rating_prob[star_rating] = p_ratings[rating_type][star_rating]
        
        words = message["text"].split()
        
        for word in words:
            for star_rating in range(1, 6):
                if (word, star_rating) in p_has_word_in_ratings[rating_type].prob:
                    if p_has_word_in_rating[word, star_rating] != 0:
                        temp_rating_prob[star_rating] *= p_has_word_in_rating[word, star_rating]
        predicted_star_rating = max(temp_rating_prob, key=temp_rating_prob.get)
        
        if predicted_star_rating == message[rating_type]:   
            correct_predictions[predicted_star_rating] += 1
        else:
            incorrect_predictions[predicted_star_rating] += 1

        total_predictions[predicted_star_rating] += 1
        
    for rating in range(1, 6):
        print("correct", correct_predictions[rating])
        print("incorrect", incorrect_predictions[rating])
        print("c ", correct_predictions)
        print("i", incorrect_predictions)
        
        total = correct_predictions[rating] + incorrect_predictions[rating]
        a = correct_predictions[rating] / total * 100
        b = correct_predictions[rating] / (correct_predictions[rating] + incorrect_predictions[rating]) * 100
        f1 = 2 * a * b / (a + b)

        print(f"Prediction accuracy for rating {rating}:\t{a:.3f}")
        print(f"Prediction recall for rating {rating}:\t{b:.3f}")
        print(f"Prediction F-1 score for rating {rating}:\t{f1:.3f}\n")


# In[ ]:




